package com.example.examen

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.examen.databinding.ActivityMainBinding
import  java.lang.NumberFormatException
import android.widget.TextView
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    private  lateinit var binding: ActivityMainBinding
    private  var operand1: Int = 0
    private var operand2: Int = 0
    private var operation: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        binding.button0.setOnClickListener {
            appendNumber("0")
        }
        binding.button1.setOnClickListener{
            appendNumber("1")
        }
        binding.button2.setOnClickListener{
            appendNumber("2")
        }
        binding.button3.setOnClickListener{
            appendNumber("3")
        }
        binding.button4.setOnClickListener{
            appendNumber("4")
        }
        binding.button5.setOnClickListener{
            appendNumber("5")
        }
        binding.button6.setOnClickListener{
            appendNumber("6")
        }
        binding.button7.setOnClickListener{
            appendNumber("7")
        }
        binding.button8.setOnClickListener{
            appendNumber("8")
        }
        binding.button9.setOnClickListener{
            appendNumber("9")
        }
        binding.buttonSuma.setOnClickListener{
            setOperation("+")
        }
        binding.buttonResta.setOnClickListener{
            setOperation("-")
        }
        binding.buttonMultipliacion.setOnClickListener{
            setOperation("*")
        }
        binding.buttonDivision.setOnClickListener{
            setOperation("/")
        }

    }
    private fun appendNumber(number: String){
        val currentText = binding.pantalla.text.toString()
        binding.pantalla.setText("$currentText$number")
    }
    private fun setOperation(op: String){
        operand1 = binding.pantalla.text.toString().toInt()
        operation = op
        binding.pantalla.text
    }
    private fun calculateResult() {
        try {
            operand2 = binding.pantalla.text.toString().toInt()
            when(operation){
                "+"->binding.textViewResult.text= "Resultado: ${operand1 + operand2}"
                "-"->binding.textViewResult.text = "Resultado: ${operand1 - operand2}"
                "*"->binding.textViewResult.text = "Resultado: ${operand1 * operand2}"
                "/" ->{
                    if(operand2 != 0){
                        binding.textViewResult.text = "Resultado: ${operand1 / operand2}"
                    } else{
                        binding.textViewResult.text = "No se puede dividir por 0"
                    }
                }
            }
        }catch (e: NumberFormatException){
            binding.textViewResult.text = "Error al Realizar la operacion"
        }
    }
}